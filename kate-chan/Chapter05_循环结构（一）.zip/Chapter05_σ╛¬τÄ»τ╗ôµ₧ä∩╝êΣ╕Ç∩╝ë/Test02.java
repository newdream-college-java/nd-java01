/*
3，循环输出100句我是傻子，再循环输出200句我怕谁？







*/
public class Test02{
	public static void main(String[] args){
		int i =1;
		while(i<=100){
			System.out.println(i+"我是傻子");

			i++;
		}
		//第1个循环结束后 i=101


		int j=1;
		while(j<=200){
			System.out.println(j+"我怕谁？");
			j++;
		}
	
	
	}
}
