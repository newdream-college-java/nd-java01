/*
输出费波纳切数列：1  1  2  3  5   8   13  ......
（规律：从第3个数开始，每个数等于前面两个数之和）
需要你编程实现输出费波纳切数列的前20位
a=1
b=1
c= a+b;
d=c+b;
e=d+c?????

======================
描述这个规律需要3个变量
int a=1 ,b=1,c
求第3个数？
	c= a+b;
	a=b;
	b=c;
第4个数？
	c=a+b;
	a=b;
	b=c;
第5个数？
	c=a+b;
	a=b;
	b=c;
......
第20个数？
	c=a+b;
	a=b;
	b=c;



*/
public class Test03{
	public static void main(String[] args){
		int a=1,b=1,c;
		//输出 第1，2个数
		System.out.print(a+"\t");
		System.out.print(b+"\t");

		int i=3
		;
		while(i<=20){
			c= a+b;
			//输出这个数
			System.out.println(c+"\t");
			a=b;
			b=c;
			i++;
		}				
		

	}
}






