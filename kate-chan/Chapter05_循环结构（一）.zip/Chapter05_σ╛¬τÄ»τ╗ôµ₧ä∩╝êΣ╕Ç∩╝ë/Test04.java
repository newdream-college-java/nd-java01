/*
编写实现向你的女朋友表白，输出：你爱我吗？
如果你的女朋友回答：不爱
继续问：你爱我吗？
如果你的女朋友回答：不爱
......
直到你的女友回答是：爱 
就结束询问。
*/
import java.util.Scanner;
public class Test04{
	public static void main(String[] args){
		Scanner input =new Scanner(System.in);
		//实现循环次数确定的循环
		//int i=1;
		//循环次数不确定的循环----循环变量不一定都是整数！！！

		String answer ="";
		//问
		//System.out.println("成绩是否合格？");
		//回答
		//answer = input.next();//不合格

		while(!answer.equals("合格")){
			//循环体---需要重复做的那件事
			System.out.println("上午阅读教材，学习理论，下午编程，掌握代码");
			//继续问？
			//问
			System.out.println("成绩是否合格？");
			//回答
			answer = input.next();//不合格
			
		}





	}
}