/*循环输入5个同学的成绩，然后计算5个同学的成绩的总分和平均分，并输出。


*/
import java.util.Scanner;
public class Test06{
	public static void main(String[] args){
		Scanner input =new Scanner(System.in);
		int sum= 0;
		int i =1;//同学的个数
		while(i<6){
			//循环体------重复做的事情
			//1,输入成绩
			System.out.println("请输入第"+i+"个同学的成绩：");
			int score = input.nextInt();

			//2,求和
			sum +=score;//sum=sum+score;

			i++;

		}
		//求平均分不是重复的操作所以放到循环外面
		double avg = sum*1.0/5;
		System.out.println("总分为："+sum+"\t平均分为："+avg);



	}
}