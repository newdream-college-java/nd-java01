/*
循环输入5个整数，然后求出这5个数字的最大值并输出最大值。

*/
import java.util.Scanner;
public class Test07{
	public static void main(String[] args){
		Scanner input =new Scanner(System.in);
		//1,假设第1个数是最大的
		System.out.print("请输入第1个数：");
		int max = input.nextInt();
		//2,后面的4个数分别于max比较
		int i =2;
		while(i<6){
			//1,重复输入整数
			System.out.println("请输入第"+i+"个数：");
			int number= input.nextInt();
			//2,重复判断
			if(number > max){
				max = number;
			}
			i++;
		}
		System.out.println("最大值为："+max);

	}
}