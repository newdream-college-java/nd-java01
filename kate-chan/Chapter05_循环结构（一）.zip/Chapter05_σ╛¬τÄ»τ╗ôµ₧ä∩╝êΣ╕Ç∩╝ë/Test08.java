public class Test08{
	public static void main(String[] args){
		int year = 2012;
		//学生总人数
		double students = 25*10000;
		//增长速度为：0.25%
		while(students<=100*10000){
			students = students*(1+0.25);
			year++;
		}
		System.out.println(year+"年学生人数为："+students);




	}


}