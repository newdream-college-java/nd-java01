/*求和：1*2*3*4......*10*/
public class Test09{
	public static void main(String[] args){

		int sum = 1;//求成绩的时候，不能初始化为0
		int i = 1;
		while(i<11){
			sum*=i;
			i++;

		}
		System.out.println("和为："+sum);

		System.out.println("==========do-while=============");
		int j = 1;
		sum = 1;
		do{
			sum*=j;
			j++;

		}while(j<11);
		System.out.println("和为："+sum);


	}

}