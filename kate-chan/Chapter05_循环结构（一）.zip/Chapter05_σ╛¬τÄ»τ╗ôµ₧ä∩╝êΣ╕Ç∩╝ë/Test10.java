public class Test10{
	public static void main(String[] args){
		int item = 1;
		int wd = 0;
		System.out.println("摄氏度\t\t华氏度");
		do{
			System.out.println(wd+"\t\t"+(wd*9/5.0+32));
			item++;
			wd +=20;
		}while(item<=10&&wd<=250);


	}
}