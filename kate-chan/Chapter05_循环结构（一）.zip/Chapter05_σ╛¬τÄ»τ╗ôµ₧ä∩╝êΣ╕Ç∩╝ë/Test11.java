/**/

public class Test11{
	public static void main(String[] args){
		int val = 12345;
		int r_digit=0;
		System.out.println("反转后的整数位：");
		while(val!=0){
			r_digit =r_digit*10+val%10;
			val=val/10;
		}
		System.out.println(r_digit);
	}
}